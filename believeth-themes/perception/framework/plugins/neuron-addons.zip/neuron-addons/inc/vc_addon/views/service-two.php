<?php
$icon_css = $title_css = $title_spacing = $padding_icon = $desc_css  = '';

if ( $icon_color != '' ) {    
        $icon_css  .= "color: {$icon_color};";  
}

if ( $size != '' ) {
    $size       = (int) $size;
    $icon_css  .= "font-size: {$size}px;";
}

if ( $icon_padding != '' ) {    
    $icon_padding = (int) $icon_padding;
    $padding_icon    .= "padding: {$icon_padding}px;";
}


if ( $title_color != '' ) {    
     $title_css  .= "color: {$title_color};";  
}


if ( $desc_color != '' ) {    
     $desc_css  .= "color: {$desc_color};";  
}

if ( $spacing_top != '' ) {  
    $title_spacing .= "padding-top: {$spacing_top}px;";  
}

if ( $spacing_bottom != '' ) {
    $title_spacing .= "margin-bottom: {$spacing_bottom}px;";
}

if ( $title_size != '' ) {
    $title_size   = (int) $title_size;
    $title_css   .= "font-size: {$title_size}px;";
}

if( $icon_style_2 == 'square' ){
	if( $icon_radiussize != '' ){
		$icon_css .= "border-radius: {$icon_radiussize}px;";
	}	
}
if( $icon_style_2 == 'square' ){
	if( $icon_radiussize != '' ){
		$icon_css .= "border-radius: {$icon_radiussize}px;";
	}	
}
elseif($icon_style_2 == 'circle'){	
	if( $icon_radiussize != '' ){		
		$icon_css .= "border-radius: {$icon_radiussize}%;";
	}
}
?>

<div class="services-main rs-services2 services-<?php echo $align; ?>" 
	data-icon-hover="<?php echo $icon_hover_color;?>" 
	data-icon-hoverbg="<?php echo $icon_hover_bg;?>" 
	data-icon-bg="<?php echo $service_icon_bg;?>" 
	data-icon-color="<?php echo $icon_color_normal;?>" 
	data-icon-sec="<?php echo $icon_color_sec; ?>"  
	data-leave-bg="<?php echo $primarybg;?>" 
	data-primay-bg="<?php echo $desc_bg_primary;?>" 
	data-secondary-bg="<?php echo $desc_bg_secondary;?>" 
	data-border-primay-bg="<?php echo $border_p_bg;?>" 
	data-border-secondary-bg="<?php echo $border_sec_bg;?>" 
	data-border-hover-bg="<?php echo $border_hover_bg;?>" 
	data-title-onhovercolor="<?php echo $title_hovercolor;?>" 
	data-title-onleavecolor="<?php echo $title_color;?>" 
	data-desc-onhovercolor="<?php echo $desc_hovercolor;?>" 
	data-desc-onleavecolor="<?php echo $desc_color;?>" 
	data-icon-onhovercolor="<?php echo $icon_hover_color2;?>" 
	data-icon-onleavecolor="<?php echo $icon_color2;?>">


	<div class="services-wrap <?php echo $service_top_style; ?> <?php echo $css_class; ?> <?php echo $css_class_custom; ?>">		
		<div class="services-item" <?php echo $desc_bg; ?>>

			<?php if($service_top_style!='bottom_border' & $service_top_style!='icon_top') { ?>
				<div class="border_top"></div>
			<?php } ?>			

			<?php if($service_top_style!='top_border' & $service_top_style!='bottom_border') { ?>
			<div class="services-icon" style="<?php echo esc_attr($padding_icon);?>">	
				<?php if(!empty($services_icon)){ ?>
					
					<i class="vc_icon_element-icon <?php echo $services_icon; ?>" style="<?php echo $icon_css;?>"
				></i>
				<?php } else { ?>
					<i class="glyph-icon <?php echo $custom_icons; ?>" style="<?php echo $icon_css;?>"
					></i>
				<?php } ?>
			</div>
			<?php } ?>

			<div class="about-title">
	            <h3 class="title"><a <?php echo $attributes; ?>><?php echo $title; ?></a></h3>
	        </div>

			<div class="services-desc">
				<p><?php echo $atts['content']; ?></p>
			</div>

			<?php if($service_top_style!='top_border' & $service_top_style!='icon_top') { ?>
				<div class="border_bottom"></div>
			<?php } ?>

		</div>	
	</div>
</div>