<?php 
	$title_css = $title_spacing = $number_css = '';

	if ( $title_color != '' ) {    
	     $title_css  .= "color: {$title_color};";  
	}

	if ( $spacing_top != '' ) {  
	    $title_spacing .= "padding-top: {$spacing_top}px;";  
	}

	if ( $spacing_bottom != '' ) {
	    $title_spacing .= "margin-bottom: {$spacing_bottom}px;";
	}

	if ( $title_size != '' ) {
	    $title_size   = (int) $title_size;
	    $title_css   .= "font-size: {$title_size}px;";
	}	

	if ( $number_font_size != '' ) {
	    $number_font_size   = (int) $number_font_size;
	    $number_css   .= "font-size: {$number_font_size}px;";
	}
	if ( $number_color != '' ) {    
	     $number_css  .= " color: {$number_color};";  
	}


	
	$html = '<div class="rs-services"><div class="service-inner services-style-10 proces-item services-'.$align.' '.$css_class.' '.$css_class_custom.'">
				<div class="services-wrap" '.$desc_bg.'> 
			        <div class="services-item">
			            <div class="number" style="'.$number_css.'"  data-onhovercolor="'.$number_hovercolor.'" data-onleavecolor="'.$number_color.'" >
			                '.$number_value.'
			            </div>
			        
						<div class="services-desc">	
							<h4 class="services-title services-title2 '.$title_transform.'" style="'.$title_spacing.'"><a data-onhovercolor="'.$title_hovercolor.'" data-onleavecolor="'.$title_color.'" '. $attributes.' style="'.$title_css.'">'.$title.'</a></h4>		
							<p '.$desc_color.'>'.$atts['content'].' </p>
						</div>		
					</div>	
				</div>
			</div>
		</div>';
	echo $html;
?>