<?php
/*
Element Description: Rs Addon 
*/
 if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
}
    // Element Mapping
     function vc_RsServices_circle_mapping() {
         
        // Stop all if VC is not enabled
        if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
        }
         
        // Map the block with vc_map()
        vc_map( 
            array(
                'name' => __('Processing Works', 'neuron'),
                'base' => 'vc_RsServices_Circle',
                'description' => __('Neuron works Information', 'neuron'), 
                'category' => __('by AuburnForest', 'neuron'),   
                'icon' => get_template_directory_uri().'/framework/assets/img/vc-icon.png',           
                'params' => array(
		    
    		    array(
    		      'type' => 'param_group',
    		      'param_name' => 'values',
    		      'params' => array(
                    array(
                        'type'       => 'dropdown',
                        'heading'    => __( 'Custom Icons', 'neuron' ),
                        'param_name' => 'custom_icons',
                        'value' => array(
                        __( 'Artificial-1', 'neuron' )   => 'flaticon-artificial-intelligence',
                        __( 'Robotic Arm', 'neuron' ) => 'flaticon-robotic-arm',
                        __( 'Ai-1', 'neuron' )  => 'flaticon-ai',
                        __( 'Play Button', 'neuron' )  => 'flaticon-play-button',
                        __( 'Artificial-2', 'neuron' )  => 'flaticon-artificial-intelligence-1',
                        __( 'Automaton', 'neuron' )  => 'flaticon-automaton',
                        __( 'Brain', 'neuron' )  => 'flaticon-brain',
                        __( 'Ai-2', 'neuron' )  => 'flaticon-ai-1',
                        __( 'Artificial-3', 'neuron' )  => 'flaticon-artificial-intelligence-2',
                        __( 'Artificial-4', 'neuron' )  => 'flaticon-artificial-intelligence-3',
                        __( 'Mail', 'neuron' )  => 'flaticon-mail',
                        __( 'Machine Learning', 'neuron' )  => 'flaticon-machine-learning',
                        __( 'Machine Learning 2', 'neuron' )  => 'flaticon-machine-learning-1',
                        __( 'Code', 'neuron' )  => 'flaticon-code',
                        __( 'Artificial-5', 'neuron' )  => 'flaticon-artificial-intelligence-4',
                        __( 'ABC', 'neuron' )  => 'flaticon-abc',
                        __( 'Contract', 'neuron' )  => 'flaticon-contract',
                        __( 'Business', 'neuron' )  => 'flaticon-business-and-finance',
                        __( 'Binary Code', 'neuron' )  => 'flaticon-binary-code',
                        __( 'Database', 'neuron' )  => 'flaticon-database',
                        __( 'Font', 'neuron' )  => 'flaticon-font',
                        __( 'Bubble', 'neuron' )  => 'flaticon-speech-bubble',
                        __( 'Face', 'neuron' )  => 'flaticon-face',
                        __( 'Facial', 'neuron' )  => 'flaticon-facial',
                        __( 'Data Search', 'neuron' )  => 'flaticon-data',
                        __( 'Recognition', 'neuron' )  => 'flaticon-facial-recognition',
                        __( 'Seo & Web', 'neuron' )  => 'flaticon-seo-and-web',
                        __( 'Encrypt-1', 'neuron' )  => 'flaticon-encrypt',
                        __( 'Encrypt-2', 'neuron' )  => 'flaticon-encrypt-1',
                        __( 'Data Encryption', 'neuron' )  => 'flaticon-data-encryption',
                        __( 'Robotics', 'neuron' )  => 'flaticon-robotics',
                        __( 'QR Code', 'neuron' )  => 'flaticon-qr',
                        __( 'Production', 'neuron' )  => 'flaticon-production',
                        __( 'Inclusion', 'neuron' )  => 'flaticon-inclusion',
                        __( 'Art Design', 'neuron' )  => 'flaticon-art-and-design',
                        __( 'Feature', 'neuron' )  => 'flaticon-feature',
                        __( 'Web Code', 'neuron' )  => 'flaticon-seo-and-web-1',               
                        ), 
                        'description' => __( 'Select Custom Icons.', 'neuron' ),
                    ),					
    		        array(
        		          'type' => 'textfield',
        		          'name' => 'label',
        		          'heading' => __('Heading', 'neuron'),
        		          'param_name' => 'label',
    		        ),
    		    )),

                array(
                    "type" => "colorpicker",
                    "class" => "",
                    'admin_label' => false,
                    "heading" => __( "Title Color", "rsaddon" ),
                    "param_name" => "title_color",
                    "value" => '',
                    "description" => __( "Choose title color", "rsaddon" ),
                    'group' => 'Styles',
                            
                ),

                array(
                    "type" => "colorpicker",
                    "class" => "",
                    'admin_label' => false,
                    "heading" => __( "Icon Color", "rsaddon" ),
                    "param_name" => "icon_color",
                    "value" => '',
                    "description" => __( "Choose icon color", "rsaddon" ),
                    'group' => 'Styles',
                            
                ),

		    	array(
					'type' => 'css_editor',
					'heading' => __( 'CSS box', 'neuron' ),
					'param_name' => 'css',
					'group' => __( 'Design Options', 'neuron' ),
				),  
		  ),

		));                     
        
    }
     
  add_action( 'vc_before_init', 'vc_RsServices_circle_mapping' );
     
    // Element HTML
    function vc_RsServices_circle_html( $atts,$content ) {
         $attributes = array();
        // Params extraction
        extract(
            shortcode_atts(
                array(					
					'title_color'   => '',
                    'icon_color'    => '',
                    'values'        => '',
					'css'           =>'',					
                ), 
                $atts,'vc_RsServices_Circle'
            )
        );     

        //for css edit box value extract
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
        $list ='';      
		$values = vc_param_group_parse_atts($atts['values']);
		$new_accordion_value = array();
		foreach($values as $data){
		$new_line = $data;

		$new_line['icon'] = isset($new_line['icon_fontawesome']) ? esc_attr($new_line['icon_fontawesome']) : 'fa fa-users';

		$new_line['label'] = isset($new_line['label']) ? $new_line['label'] : '';
		$new_line['excerpt'] = isset($new_line['excerpt']) ? $new_line['excerpt'] : '';		
		$new_accordion_value[] = $new_line;}

        $show_title_color = '';
        if( $title_color != ''){
            $show_title_color ='style="color:'.$title_color.'"';
        }

        $show_icon_color = '';
        if( $icon_color != ''){
            $show_icon_color ='style="color:'.$icon_color.'"';
        }		

  		$list .='<div class="neuron-processing-work '.$css_class.'">
                    <div class="neuron-work">';
    			  		foreach($new_accordion_value as $accordion):
    						$list .='<div class="single-work text-center"> 
                            <div class="work-icon hover-pulse">
                                <i '.$show_icon_color.' class="glyph-icon '.$accordion['custom_icons'].' "></i>
                            </div>
                            <div class="work-title">
                                <h3 '.$show_title_color.' class="title">'.$accordion['label'].'</h3>
                            </div>
    					</div>';    					
    					endforeach;
    				$list .='
                    </div>
				</div>';		
		
		return $list;
		wp_reset_query();						
	}
add_shortcode( 'vc_RsServices_Circle', 'vc_RsServices_circle_html' ); 